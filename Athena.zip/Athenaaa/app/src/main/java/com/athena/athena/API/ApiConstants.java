package com.athena.athena.API;

/**
 * Created by Kunal
 * on 5/5/2017.
 */

public class ApiConstants {

    public static final String IMAGE_URL = "http://diestechnology.com.au/projects/athena/";
    public static final String BASE_URL = "http://diestechnology.com.au/projects/athena/app_controller/";
    public static final String PDF_URL = "http://diestechnology.com.au/projects/athena/";

    //new server
    /*public static final String IMAGE_URL = "http://diestechnology.com/projects/athena/";
    public static final String BASE_URL = "http://diestechnology.com/projects/athena/app_controller/";
    public static final String PDF_URL = "http://diestechnology.com/projects/athena/";*/

}
