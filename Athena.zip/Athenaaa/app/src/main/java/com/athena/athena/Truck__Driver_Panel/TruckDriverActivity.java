package com.athena.athena.Truck__Driver_Panel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.athena.athena.Activity.LoginActivity;
import com.athena.athena.Activity.Profile;
import com.athena.athena.R;
import com.athena.athena.application.SessionManager;
import com.athena.athena.application.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class TruckDriverActivity extends AppCompatActivity {


    @BindView(R.id.profile)
    LinearLayout profile;
    /* @BindView(R.id.ll_timelog)
     LinearLayout ll_timelog;*/
    @BindView(R.id.ll_assignedordr)
    LinearLayout ll_assignedordr;
    /*@BindView(R.id.ll_todayordr)
    LinearLayout ll_todayordr;*/
    @BindView(R.id.ll_todaytrip)
    LinearLayout ll_todaytrip;
    @BindView(R.id.ll_cmpltdordr)
    LinearLayout ll_cmpltdordr;
    /*
       @BindView(R.id.ll_ordrstausmngmnt)
       LinearLayout ll_ordrstausmngmnt;*/
    @BindView(R.id.ll_logout)
    LinearLayout ll_logout;
    @BindView(R.id.txt_user)
    TextView txt_user;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_truck_driver);
        ButterKnife.bind(this);
        sessionManager = new SessionManager(this);

        txt_user.setText(sessionManager.getKeyName() + " " + sessionManager.getKeyLname());

        profile.setOnClickListener(view -> {
            Intent intent = new Intent(TruckDriverActivity.this, Profile.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
        ll_todaytrip.setOnClickListener(view -> {
            Intent intent = new Intent(TruckDriverActivity.this, TodayTripActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        ll_assignedordr.setOnClickListener(view -> {
            /*if (sessionManager.getKeyTruckid().equals("")) {
                Utility.displayToast(this, "Please Select Truck From Vehicle Defect Report");
            } else {*/
            Intent intent = new Intent(TruckDriverActivity.this, AssignOrderActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            //}
        });

        /*ll_todayordr.setOnClickListener(view -> {
            if (sessionManager.getKeyTruckid().equals("")) {
                Utility.displayToast(this, "Please Select Truck From Vehicle Defect Report");
            } else {
                Intent intent = new Intent(TruckDriverActivity.this, TodaysOrderActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });*/

        ll_cmpltdordr.setOnClickListener(view -> {
            Intent intent = new Intent(TruckDriverActivity.this, CompletedOrderActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });

        ll_logout.setOnClickListener(view -> {
            sessionManager.logoutUser();
            Intent i = new Intent(getApplicationContext(), LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });
    }
}
