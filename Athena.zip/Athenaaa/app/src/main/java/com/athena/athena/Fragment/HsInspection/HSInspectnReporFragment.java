package com.athena.athena.Fragment.HsInspection;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.athena.athena.API.ApiInterface;
import com.athena.athena.API.ApiServiceCreator;
import com.athena.athena.Fragment.HsQuestion.CompetenceTraningFragment;
import com.athena.athena.MainActivity;
import com.athena.athena.Model.CommanModel;
import com.athena.athena.Model.Example;
import com.athena.athena.Model.HSInspectionModel;
import com.athena.athena.Model.HSQuestionModel;
import com.athena.athena.Model.Model;
import com.athena.athena.R;
import com.athena.athena.adapter.HSInspectnQuesAdapter;
import com.athena.athena.adapter.QuestionAdapter;
import com.athena.athena.application.SessionManager;
import com.athena.athena.application.Utility;
import com.wang.avi.AVLoadingIndicatorView;

import java.net.SocketTimeoutException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Observer;
import rx.schedulers.Schedulers;

import static com.athena.athena.adapter.HSInspectnQuesAdapter.hsquestiondataList;


/**
 * A simple {@link Fragment} subclass.
 */
public class HSInspectnReporFragment extends Fragment {

    @BindView(R.id.toolbar_Title)
    TextView toolbar_Title;
    @BindView(R.id.back_icon)
    ImageView back_icon;
    @BindView(R.id.btn_next)
    LinearLayout btn_next;
    @BindView(R.id.avi)
    AVLoadingIndicatorView avi;
    @BindView(R.id.btn_previous)
    LinearLayout btn_previous;
    @BindView(R.id.recyerview)
    RecyclerView recyerview;
    @BindView(R.id.txt_failed)
    public TextView txt_failed;
    @BindView(R.id.txt_percntg)
    public TextView txt_percntg;
    @BindView(R.id.txt_fld)
    public TextView txt_fld;
    @BindView(R.id.txt_per)
    public TextView txt_per;

    DecimalFormat format = new DecimalFormat("0.00");

    private SessionManager sessionManager;
    private ApiInterface apiservice;
    private int statusCode;
    ArrayList<HSQuestionModel.Data> arrayList;
    private RecyclerView.LayoutManager layoutManager;
    HSInspectnQuesAdapter adapter;
    HSInspectionModel hs;
    String validation = "No";


    public HSInspectnReporFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view1 = inflater.inflate(R.layout.fragment_hs, container, false);
        ButterKnife.bind(this, view1);
        sessionManager = new SessionManager(getActivity());
        apiservice = ApiServiceCreator.createService("latest");
        toolbar_Title.setText("Inspection and Reporting");


        hsquestiondataList = new ArrayList<>();
        hsquestiondataList.clear();

        back_icon.setOnClickListener(view -> getActivity().onBackPressed());
        btn_previous.setOnClickListener(view -> getActivity().onBackPressed());


        btn_next.setOnClickListener(view -> {

            hs = new HSInspectionModel();
            hs.setAns_user_id(sessionManager.getKeyId());
            hs.setLast_step(Utility.getAppcon().getSession().hs_data_value);
            hs.setAns_failed(txt_failed.getText().toString());
            hs.setAns_score(txt_percntg.getText().toString());
            hs.setQuestions_hs(hsquestiondataList);

            //for (int i = 0; i < HSInspectnQuesAdapter.hsquestiondataList.size(); i++) {
//            if (hsquestiondataList.get(0).getAns_ques_status().equals("")) {
//                Utility.displayToast(getActivity(), "Please Select Inspection Status");
//            } else {
            //callNextApi();

            //}
            //}

            if (validation.equals("No")) {
                Toast.makeText(getActivity(), "Please Select Inspection Status", Toast.LENGTH_LONG).show();
            } else {
                callNextApi();
            }
        });


        getQuestionApi();
        return view1;
    }

    private void callNextApi() {

        avi.show();
        Observable<Model> responseObservable = apiservice.insert_inspectionHsDetails(hs);
        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(rx.android.schedulers.AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<Model>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("error", "" + e.getMessage());
                    }

                    @Override
                    public void onNext(Model model) {
                        avi.hide();
                        statusCode = model.getStatusCode();
                        if (statusCode == 200) {
                            Utility.displayToast(getActivity(), model.getMessage());
                            HSDocumntnFragment fragment = new HSDocumntnFragment();
                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.add(R.id.frm, fragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                        } else {
                            Utility.displayToast(getActivity(), model.getMessage());
                        }
                    }
                });

    }

    private void getQuestionApi() {

        recyerview.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        recyerview.setLayoutManager(layoutManager);

        avi.show();
        Observable<HSQuestionModel> responseObservable = apiservice.get_all_HSQuestion();

        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(rx.android.schedulers.AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<HSQuestionModel>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                    }

                    @Override
                    public void onError(Throwable hs) {
                        Log.e("error", "" + hs.getMessage());
                    }

                    @Override
                    public void onNext(HSQuestionModel model) {
                        avi.hide();
                        statusCode = model.getStatusCode();
                        if (statusCode == 200) {

                            Utility.getAppcon().getSession().arrayListHSInsctnQuestion = new ArrayList<>();
                            Utility.getAppcon().getSession().arrayListHSInsctnQuestion = model.getData();

                            arrayList = model.getData();

                            List<CommanModel> commanModelslist = new ArrayList<>();

                            for (int i = 0; i < model.getData().get(0).getInspectionAndReporting().size(); i++) {
                                CommanModel commanModel = new CommanModel();
                                commanModel.setHsId(model.getData().get(0).getInspectionAndReporting().get(i).getHsId());
                                commanModel.setHsLabel(model.getData().get(0).getInspectionAndReporting().get(i).getHsLabel());
                                commanModel.setHsQues(model.getData().get(0).getInspectionAndReporting().get(i).getHsQues());
                                commanModelslist.add(commanModel);
                            }

                            Utility.displayToast(getActivity(), model.getMessage());
                            adapter = new HSInspectnQuesAdapter(getActivity(), commanModelslist, "hsincpcnreportng", new HSInspectnQuesAdapter.OnItemClickListener() {
                                @Override
                                public void onItemClick(Double item, int item1, String validation1) {

                                    if (item == 100.0) {
                                        validation = validation1;
                                        txt_percntg.setTextColor(Color.parseColor("#4CAF50"));
                                        txt_per.setTextColor(Color.parseColor("#4CAF50"));
                                        txt_percntg.setText(String.valueOf(format.format((item))));
                                        txt_failed.setVisibility(View.GONE);
                                        txt_fld.setVisibility(View.GONE);
                                        //txt_failed.setText(String.valueOf(item1) + "failed");

                                        Log.e("TAG", "perctng-- " + item);
                                    } else {
                                        txt_failed.setVisibility(View.VISIBLE);
                                        txt_fld.setVisibility(View.VISIBLE);
                                        validation = validation1;
                                        txt_percntg.setTextColor(Color.parseColor("#FD9832"));
                                        txt_per.setTextColor(Color.parseColor("#FD9832"));
                                        txt_percntg.setText(String.valueOf(format.format((item))));
                                        txt_failed.setText(String.valueOf(item1));
                                        Log.e("TAG", "perctng-- " + item);
                                        Log.e("TAG", "faild-- " + item1);

                                    }
                                }
                            });
                            recyerview.setAdapter(adapter);
                        } else {
                            Utility.displayToast(getActivity(), model.getMessage());
                        }
                    }
                });

    }
}


