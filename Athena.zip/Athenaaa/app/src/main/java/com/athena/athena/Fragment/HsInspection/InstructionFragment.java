package com.athena.athena.Fragment.HsInspection;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.athena.athena.API.ApiInterface;
import com.athena.athena.API.ApiServiceCreator;
import com.athena.athena.Fragment.HsQuestion.InspctnandReprtngFragment;
import com.athena.athena.MainActivity;
import com.athena.athena.Model.SpinnerModel;
import com.athena.athena.R;
import com.athena.athena.application.SessionManager;
import com.athena.athena.application.Utility;
import com.wang.avi.AVLoadingIndicatorView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Observer;
import rx.schedulers.Schedulers;

/**
 * A simple {@link Fragment} subclass.
 */
public class InstructionFragment extends Fragment {

    @BindView(R.id.toolbar_Title)
    TextView toolbar_Title;
    @BindView(R.id.back_icon)
    ImageView back_icon;
    @BindView(R.id.btn_next)
    LinearLayout btn_next;

    @BindView(R.id.btn_previous)
    LinearLayout btn_previous;

    private SessionManager sessionManager;
    private ApiInterface apiservice;
    private int statusCode;


    public InstructionFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view1 = inflater.inflate(R.layout.fragment_instructn, container, false);
        ButterKnife.bind(this, view1);
        sessionManager = new SessionManager(getActivity());
        apiservice = ApiServiceCreator.createService("latest");
        toolbar_Title.setText("Instruction");

        back_icon.setOnClickListener(view -> {
            getActivity().onBackPressed();
        });

        btn_previous.setOnClickListener(view -> getActivity().onBackPressed());
        btn_next.setOnClickListener(view -> {
            HSInspectnReporFragment fragment = new HSInspectnReporFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.frm, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        });
        return view1;
    }

}


