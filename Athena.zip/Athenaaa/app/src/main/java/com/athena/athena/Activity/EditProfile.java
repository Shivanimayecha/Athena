package com.athena.athena.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.athena.athena.API.APIClient;
import com.athena.athena.API.ApiInterface;
import com.athena.athena.CompressImageUtils;
import com.athena.athena.Constant;
import com.athena.athena.ImageFilePath;
import com.athena.athena.Model.PositionModel;
import com.athena.athena.Model.SpinnerModel;
import com.athena.athena.R;
import com.athena.athena.Utilities;
import com.google.gson.JsonElement;

import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.R.layout.simple_spinner_item;

public class EditProfile extends Activity {

    public static ApiInterface apiInterface;
    public static String strProvider = "com.android.disethech.athena.provider";

    private static final int REQUEST_PERMISSION_WRITE_STORAGE = 111;
    private static final int REQUEST_PERMISSION_CAMERA = 112;
    private static final int REQUEST_PERMISSION_BOTH = 113;
    private final Handler handler = new Handler();
    private final int REQUEST_CAMERA = 1;
    private final int SELECT_FILE = 2;

    private ArrayList<String> positionString = new ArrayList<>();
    private ArrayList<PositionModel> positionModels = new ArrayList<>();
    private List<PositionModel.Data> positionDatum = new ArrayList<>();
    EditText username_edt, work_edt, bankdetails_edt, ifsc_edt, bank_edt, hourly_edt, site_edt, contant_edt, email_edt;
    TextView change_pro_txt;
    Spinner spinner_postion;
    CircleImageView profilepic;
    String msg, selectedImagePath;
    File file;
    private Uri picUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_edit_profil);
        apiInterface = APIClient.getAPIClient().create(ApiInterface.class);

        ImageView img_back = findViewById(R.id.branding_icon);
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch (view.getId()) {
                    case R.id.branding_icon:
                        finish();
                        break;
                    default:
                        break;
                }
            }
        });
        DefinaView();
        ProfileUser1();
        singleitem();
    }

    public void DefinaView() {
        spinner_postion = findViewById(R.id.spinner_position);
        username_edt = findViewById(R.id.username_edt);
        change_pro_txt = findViewById(R.id.change_pro_txt);
        change_pro_txt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });
        profilepic = findViewById(R.id.profilepic);
        ImageView img_back = findViewById(R.id.save);
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validate()) {
                    Intent intent = new Intent(getApplicationContext(), Profile.class);
                    startActivity(intent);
                    EditProfileup(username_edt.getText().toString().trim(), spinner_postion.toString().trim());

                } else {

                }


            }
        });

    }

    private boolean validate() {
        // check the lenght of the enter data in EditText and give error if its empty


        boolean valid = true;

        String username = username_edt.getText().toString();

        if (username.isEmpty()) {
            username_edt.setError("enter a Username");
            valid = false;
        } else {
            username_edt.setError(null);
        }
        return valid;

    }

    private void EditProfileup(String username, String positions) {
        //showProgressDialog();
        final String userid = Utilities.getSharedPreferences(getApplicationContext(), Constant.LOGIN_ID);
        Call<JsonElement> call = (Call<JsonElement>) apiInterface.getUpdateProfile(userid, username, positions);
        call.enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                //  dismissProgressDialog();
                try {

                    Log.e("Update Profile res ", response.body().toString());
                    JSONObject object = new JSONObject(response.body().toString());
                    String status = object.getString("statusCode");
                    msg = object.getString("message");

                    if (status.equals("200")) {

                        Toast.makeText(EditProfile.this, msg, Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(EditProfile.this, msg, Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable t) {
                //  dismissProgressDialog();
            }
        });
    }

    private void ProfileUser1() {

        //showProgressDialog();
        final String userid = Utilities.getSharedPreferences(getApplicationContext(), Constant.LOGIN_ID);
        Call<PositionModel> call = (Call<PositionModel>) apiInterface.getPosition(userid);
        call.enqueue(new Callback<PositionModel>() {
            @Override
            public void onResponse(Call<PositionModel> call, Response<PositionModel> response) {
                //  dismissProgressDialog();
                try {

                    Log.e("Profile res ", response.body().toString());

                    positionModels.add(response.body());
                    positionDatum = response.body().getData();
                    for (int i = 0; i < positionDatum.size(); i++) {
                        positionString.add(response.body().getData().get(i).getUpName());
                    }

                    ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(EditProfile.this, simple_spinner_item, positionString);
                    spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down view
                    spinner_postion.setAdapter(spinnerArrayAdapter);


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<PositionModel> call, Throwable t) {
                //  dismissProgressDialog();
            }
        });
    }

    private void singleitem() {


        String id = Utilities.getSharedPreferences(getApplicationContext(), Constant.LOGIN_ID);

        if (file == null) {
        } else {
            RequestBody requestFile =
                    RequestBody.create(MediaType.parse("multipart/form-data"), file);

// MultipartBody.Part is used to send also the actual file name
            MultipartBody.Part body =
                    MultipartBody.Part.createFormData("image", file.getName(), requestFile);

// add another part within the multipart request
            RequestBody pids = RequestBody.create(MediaType.parse("multipart/form-data"), id);


            Call<JsonElement> call1 = apiInterface.UpdateImage(pids, body);
            call1.enqueue(new Callback<JsonElement>() {
                @Override
                public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {
                    try {

                        Log.e("Update Profile res ", response.body().toString());
                        JSONObject object = new JSONObject(response.body().toString());
                        String status = object.getString("statusCode");
                        msg = object.getString("message");

                        if (status.equals("200")) {

                            Toast.makeText(EditProfile.this, msg, Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(EditProfile.this, msg, Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<JsonElement> call, Throwable t) {
                }
            });

        }
    }

    private void selectImage() {
        final CharSequence[] items = {"Choose from Library", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(EditProfile.this);
        builder.setTitle("Add Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @SuppressLint("IntentReset")
            @Override
            public void onClick(DialogInterface dialog, int item) {
                try {

                    if (items[item].equals("Choose from Library")) {


                        if (ContextCompat.checkSelfPermission(EditProfile.this,
                                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                                ContextCompat.checkSelfPermission(EditProfile.this,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(EditProfile.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_PERMISSION_BOTH);
                            return;
                        }

                        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        intent.setType("image/*");
                        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
                    } else if (items[item].equals("Cancel")) {
                        dialog.dismiss();
                    }
                } catch (ActivityNotFoundException e) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            String FileType = null;
            Uri selectedFileUri = data.getData();

            if (requestCode == SELECT_FILE && data != null) {

                int REQUIRED_SIZE = 1024;

                Uri PickFilepath = data.getData();
                selectedImagePath = ImageFilePath.getPath(EditProfile.this, data.getData());
                File file2 = new File(selectedImagePath);
                String destFolder = EditProfile.this.getCacheDir().getAbsolutePath() + "/" + file2.getName();
                CompressImageUtils.compress(selectedImagePath, destFolder, REQUIRED_SIZE, REQUIRED_SIZE, 80);
                String ImageName = destFolder.substring(destFolder.lastIndexOf("/") + 1);
                file = new File(destFolder);
                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());

                profilepic.setImageBitmap(bitmap);
                change_pro_txt.setText(ImageName);
            }

        }


    }


    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private File getOutputMediaFile() {
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "Divya");

        /**Create the storage directory if it does not exist*/
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }

        /**Create a media file name*/
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");
        return mediaFile;
    }

    @SuppressLint("IntentReset")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_PERMISSION_BOTH:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //reload my activity with permission granted or use the features what required the permission
                    change_pro_txt.callOnClick();
                }
                break;

            case REQUEST_PERMISSION_CAMERA:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File file = getOutputMediaFile();
                    if (file != null)
                        picUri = FileProvider.getUriForFile(EditProfile.this, strProvider, file);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, picUri);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(intent, REQUEST_CAMERA);
                }
                break;

            case REQUEST_PERMISSION_WRITE_STORAGE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
                }
                break;
        }
    }

}
