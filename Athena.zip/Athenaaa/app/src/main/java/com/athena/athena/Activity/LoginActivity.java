package com.athena.athena.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.athena.athena.API.ApiInterface;
import com.athena.athena.API.ApiServiceCreator;
import com.athena.athena.MainActivity;
import com.athena.athena.Model.LoginResponse;
import com.athena.athena.Model.UserDataResponse;
import com.athena.athena.R;
import com.athena.athena.Truck__Driver_Panel.TruckDriverActivity;
import com.athena.athena.application.SessionManager;
import com.athena.athena.application.Utility;
import com.google.gson.Gson;
import com.wang.avi.AVLoadingIndicatorView;

import java.net.SocketTimeoutException;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.edt_username)
    EditText edt_username;

    @BindView(R.id.edt_password)
    EditText edt_password;

    @BindView(R.id.btn_login)
    Button btn_login;
    @BindView(R.id.avi)
    AVLoadingIndicatorView avi;

    ProgressDialog pDialog;
    ApiInterface apiservice;
    int statusCode;
    SessionManager sessionManager;
    private String Token;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_loginscreen);
        ButterKnife.bind(this);

        apiservice = ApiServiceCreator.createService("latest");
        sessionManager = new SessionManager(LoginActivity.this);


    /*    if (sessionManager.isLoggedIn()) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
        }*/

        btn_login.setOnClickListener(view -> {
            if (edt_username.getText().toString().equals("")) {
                Utility.displayToast(getApplicationContext(), "Please enter Mobileno");
            } else if (edt_password.getText().toString().equals("")) {
                Utility.displayToast(getApplicationContext(), "Please enter Password");
            } else {
                checkLogin(edt_username.getText().toString(), edt_password.getText().toString());
            }
        });

    }

    private void checkLogin(String email, String pwd) {

        avi.show();
        Log.e("data", email + pwd);
        Observable<LoginResponse> responseObservable = apiservice.loginUser(email, pwd);
        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<LoginResponse>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("error", "" + e.getMessage());
                    }

                    @Override
                    public void onNext(LoginResponse loginResponse) {
                        statusCode = loginResponse.getStatusCode();
                        if (statusCode == 200) {
                           avi.hide();
                            Utility.displayToast(getApplicationContext(),loginResponse.getMessage());

                            Token = loginResponse.getData().get(0).getToken();
                            sessionManager.setKeyEmail(email);
                            sessionManager.setLoginType("normal");

                            Log.e("token---->", "onNext: " + Token);
                            getUserDetail();
                        } else {
                            Utility.displayToast(getApplicationContext(),loginResponse.getMessage());
                        }
                    }
                });
    }

    private void getUserDetail() {

        avi.show();
        Observable<UserDataResponse> responseObservable = apiservice.getUserDetails(sessionManager.getKeyEmail());
        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<UserDataResponse>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                       }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("error", e.getLocalizedMessage());
                    }

                    @Override
                    public void onNext(UserDataResponse userDataResponse) {
                        statusCode = userDataResponse.getStatusCode();
                        if (statusCode == 200) {
                            sessionManager.setKeyUserDetails(new Gson().toJson(userDataResponse.getData()));
                            sessionManager.setKeyToken(Token);
                            Log.e("user_type", userDataResponse.getData().get(0).getUserType());
                            Log.e("user_id", userDataResponse.getData().get(0).getUserId());
                            sessionManager.setKeyRoll(userDataResponse.getData().get(0).getUserType());
                            sessionManager.setKeyId(userDataResponse.getData().get(0).getUserId());
                            sessionManager.setKeyPassword(edt_password.getText().toString());
                            sessionManager.setKeyName(userDataResponse.getData().get(0).getName());
                            sessionManager.setKeyLname(userDataResponse.getData().get(0).getLname());
                            sessionManager.createLoginSession();
                            if (sessionManager.getKeyRoll().equals("Supervisor")) {
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Intent intent = new Intent(LoginActivity.this, TruckDriverActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }
                });
    }


}
