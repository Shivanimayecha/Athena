package com.athena.athena.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.athena.athena.API.ApiConstants;
import com.athena.athena.Model.PastHsModel;
import com.athena.athena.R;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class JobReportAdapter extends RecyclerView.Adapter<JobReportAdapter.MyviewHolder> {

    Context mContext;
    List<PastHsModel.Data> arraylist;

    public JobReportAdapter(Context mContext, List<PastHsModel.Data> arraylist) {
        this.mContext = mContext;
        this.arraylist = arraylist;
    }

    @NonNull
    @Override
    public JobReportAdapter.MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.jobreprt_list, parent, false);
        return new MyviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JobReportAdapter.MyviewHolder holder, int position) {

        /*holder.txt_sitename.setText(arraylist.get(position).getJb_site_name());
        holder.txt_contractorname.setText(arraylist.get(position).getJb_laber_name());
        holder.txt_plntnme.setText(arraylist.get(position).getJb_plant_name());
        holder.txt_qty.setText(arraylist.get(position).getJb_quantity());
        holder.txt_wrkonsite.setText(arraylist.get(position).getJb_work_on_site_notes());*/

        holder.txt_date.setText("Date :- " + arraylist.get(position).getJb_date());

        holder.btn_pdf.setOnClickListener(view ->
        {
            String pdf_url = arraylist.get(0).getJb_new_pdf();
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(ApiConstants.PDF_URL + Uri.parse(pdf_url)));
            mContext.startActivity(browserIntent);
        });
    }

    @Override
    public int getItemCount() {
        return arraylist.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder {

        /*@BindView(R.id.txt_sitename)
        TextView txt_sitename;
        @BindView(R.id.txt_contractorname)
        TextView txt_contractorname;
        @BindView(R.id.txt_plntnme)
        TextView txt_plntnme;
        @BindView(R.id.txt_qty)
        TextView txt_qty;
        @BindView(R.id.txt_wrkonsite)
        TextView txt_wrkonsite;*/
        @BindView(R.id.txt_date)
        TextView txt_date;
        /* @BindView(R.id.txt_name)
         TextView txt_name;*/
        @BindView(R.id.btn_pdf)
        Button btn_pdf;

        public MyviewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
