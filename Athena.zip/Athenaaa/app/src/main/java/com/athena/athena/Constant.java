package com.athena.athena;





public class Constant {

    public static final String LOGIN_STATUS = "login_status";
    public static final String LOGIN_ID = "loginid";
    public static final String TICKET_ID = "ticket_id";
    public static final String ORDER_ID = "order_id";
    public static final String PACKAGE_ID ="package_id" ;
    public static final String EVENT_ID ="event_id" ;

    public static final String TOTAL ="amount" ;
    public static final String STOCK_TYPE ="stock_type";
    public static final String MAX ="max";
    public static final String MIN ="min";
    public static final String EMAIL ="emailid";
    public static final String CUSTOMERID ="customerid";
    public static final String DATESSELECT ="customerid";
}

