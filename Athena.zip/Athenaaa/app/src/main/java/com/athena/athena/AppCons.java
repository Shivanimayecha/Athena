package com.athena.athena;

public class AppCons {
    public static String STATUS = "Status";
    public static String DISPLAY_TODO = "DISPLAY_TODO" ;

    public static String STATUS_LOGIN = "Login";
    public static String STATUS_LOGOUT = "Logout";
    public static String USER = "User";
    public static String ACCOUNT = "Account";
    public static String DISPATCH = "Dispatch";
    //JSON array name
    public static final String JSON_ARRAY = "result";
}
