package com.athena.athena.orderHistory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.athena.athena.API.ApiInterface;
import com.athena.athena.API.ApiServiceCreator;
import com.athena.athena.Model.OrderDetailsModel;
import com.athena.athena.Model.OrderStatusModel;
import com.athena.athena.Model.SpinnerModel;
import com.athena.athena.R;
import com.athena.athena.adapter.OrderDetialsAdapter;
import com.athena.athena.application.SessionManager;
import com.athena.athena.application.Utility;
import com.wang.avi.AVLoadingIndicatorView;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import rx.Observable;
import rx.Observer;
import rx.schedulers.Schedulers;

public class OpenOrderHistoryList extends AppCompatActivity {

    @BindView(R.id.toolbar_Title)
    TextView toolbar_Title;
    @BindView(R.id.back_icon)
    ImageView back_icon;
    @BindView(R.id.avi)
    AVLoadingIndicatorView avi;
    @BindView(R.id.spn_site)
    Spinner spn_site;

    @BindView(R.id.rv_orderlist)
    RecyclerView rv_orderlist;
    int statusCode;
    List<SpinnerModel.Data> data;
    List<OrderStatusModel.Data> data1;
    String site = "", s_id = "", order = "", o_id = "";
    ArrayList<String> sitearray = new ArrayList<>();
    ArrayList<String> orderarray = new ArrayList<>();
    SessionManager sessionManager;
    ApiInterface apiservice;
    OrderDetialsAdapter adapter;
    RecyclerView.LayoutManager layoutManager;
    public static Handler handler = null;
    ArrayAdapter<String> siteAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_open_order_history_list);
        ButterKnife.bind(this);
        sessionManager = new SessionManager(OpenOrderHistoryList.this);
        apiservice = ApiServiceCreator.createService("latest");
        toolbar_Title.setText("Pending Orders");
        Utility.getAppcon().getSession().screen_name = "openOderHistoryList";

        initViews();
        checkHandller();
    }

    private void initViews() {

        rv_orderlist.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        rv_orderlist.setLayoutManager(layoutManager);

        back_icon.setOnClickListener(view -> finish());

        s_id = getIntent().getStringExtra("site");
        Log.e("TAG", "initViews: site--" + s_id);

        getSiteName();
        spn_site.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (spn_site.getSelectedItem() == "Select site") {
                    site = "";
                } else {
                    site = spn_site.getSelectedItem().toString();
                    SpinnerModel.Data datalist = data.get(i - 1);
                    s_id = datalist.getSiteId();
                    callOrderHistoryApi();
                    String[] separated = site.split(",");
                    //contract_no=separated[0];
                    site=separated[1];
                    Log.e("Sitename is ",site);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }

    @SuppressLint("HandlerLeak")
    public void checkHandller() {
        handler = new Handler() {
            @Override
            public void handleMessage(Message message) {
                if (message == null) {

                }
                if (message.what == 100) {
                    callOrderHistoryApi();
                }
            }
        };
    }

    private void callOrderHistoryApi() {
        avi.show();
        Log.e("s_id",s_id);
        Observable<OrderDetailsModel> responseObservable = apiservice.get_openOrders(s_id);
        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(rx.android.schedulers.AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<OrderDetailsModel>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("error", "" + e.getMessage());
                    }

                    @Override
                    public void onNext(OrderDetailsModel model) {
                        avi.hide();

                        statusCode = model.getStatusCode();
                        if (statusCode == 200) {
                            Utility.displayToast(getApplicationContext(), model.getMessage());
                            adapter = new OrderDetialsAdapter(OpenOrderHistoryList.this, model.getData());
                            rv_orderlist.setAdapter(adapter);
                        } else if (statusCode == 404) {
                            Utility.displayToast(getApplicationContext(), model.getMessage());
                        }
                    }
                });
    }

    private void getSiteName() {

        avi.show();
        //Observable<SpinnerModel> responseObservable = apiservice.get_userSite(sessionManager.getKeyId());
        Observable<SpinnerModel> responseObservable = apiservice.get_site();

        responseObservable.subscribeOn(Schedulers.newThread())
                .observeOn(rx.android.schedulers.AndroidSchedulers.mainThread())
                .onErrorResumeNext(throwable -> {
                    if (throwable instanceof retrofit2.HttpException) {
                        retrofit2.HttpException ex = (retrofit2.HttpException) throwable;
                        statusCode = ex.code();
                        Log.e("error", ex.getLocalizedMessage());
                    } else if (throwable instanceof SocketTimeoutException) {
                        statusCode = 1000;
                    }
                    return Observable.empty();
                })
                .subscribe(new Observer<SpinnerModel>() {
                    @Override
                    public void onCompleted() {
                        avi.hide();
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e("error", "" + e.getMessage());
                    }

                    @Override
                    public void onNext(SpinnerModel model) {
                        statusCode = model.getStatusCode();
                        if (statusCode == 200) {
                            data = model.getData();
                            for (int i = 0; i < model.getData().size(); i++) {
                                sitearray.add(model.getData().get(i).getSite_number()+" , "+model.getData().get(i).getSiteName());
                            }
                            siteAdapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.spinner_item, sitearray);
                            siteAdapter.insert("Select site", 0);
                            siteAdapter.setDropDownViewResource(R.layout.spinner_item);
                            spn_site.setAdapter(siteAdapter);

                            String compareValue = s_id;
                            if (compareValue != null) {
                                int spinnerPosition = siteAdapter.getPosition(compareValue);
                                spn_site.setSelection(spinnerPosition);

                                Log.e("spinnerPosition", "" + spinnerPosition);
                            }
                        }
                    }
                });
    }
}
